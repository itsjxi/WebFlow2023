export const navbarData =[
  {
    label:"Product",
    id:1
  },
  {
    label:"Solutions",
    id:2
  },
  {
    label:"Tools",
    id:3
  },
  {
    label:"Pricing",
    id:4
  },
  {
   label:"Company" ,
   id:5
  },
  {
    label:"Resouces",
    id:6
  }
]
  
  
